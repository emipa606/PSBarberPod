﻿using System;
using RimWorld;
using Verse;

namespace PS_BarberPod
{
    // Token: 0x02000028 RID: 40
    [DefOf]
    public static class BarberPodDefsOf
    {
        // Token: 0x04000044 RID: 68
        public static JobDef UseBarberPod;
    }
}
